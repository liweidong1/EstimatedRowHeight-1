//  代码地址: https://github.com/iphone5solo/PYPhotosView
//  代码地址: http://code4app.com/thread-8612-1-1.html
//  Created by CoderKo1o.
//  Copyright © 2016年 iphone5solo. All rights reserved.
//  用于发布时，本地图片预览的导航控制器

#import <UIKit/UIKit.h>

@interface PYNavigationController : UINavigationController

@end
